# `acpi -bi`

```bash
Battery 0: Charging, 82%, 00:22:50 until charged
Battery 0: design capacity 7248 mAh, last full capacity 3610 mAh = 49%
```
