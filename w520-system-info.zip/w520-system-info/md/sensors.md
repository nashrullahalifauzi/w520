# `sensors`

```bash
thinkpad-isa-0000
Adapter: ISA adapter
fan1:        2534 RPM

nouveau-pci-0100
Adapter: PCI adapter
GPU core:         N/A  (min =  +0.83 V, max =  +1.08 V)
temp1:            N/A  (high = +95.0°C, hyst =  +3.0°C)
                       (crit = +105.0°C, hyst =  +5.0°C)
                       (emerg = +135.0°C, hyst =  +5.0°C)

acpitz-acpi-0
Adapter: ACPI interface
temp1:        +43.0°C  (crit = +99.0°C)

coretemp-isa-0000
Adapter: ISA adapter
Package id 0:  +44.0°C  (high = +86.0°C, crit = +100.0°C)
Core 0:        +43.0°C  (high = +86.0°C, crit = +100.0°C)
Core 1:        +42.0°C  (high = +86.0°C, crit = +100.0°C)
Core 2:        +44.0°C  (high = +86.0°C, crit = +100.0°C)
Core 3:        +44.0°C  (high = +86.0°C, crit = +100.0°C)

BAT0-acpi-0
Adapter: ACPI interface
in0:          11.85 V  
```
