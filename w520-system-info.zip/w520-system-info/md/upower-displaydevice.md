# `display-device`

```bash
  power supply:         yes
  updated:              Tue 05 Nov 2024 04:14:16 PM WIB (9 seconds ago)
  has history:          no
  has statistics:       no
  battery
    present:             yes
    state:               discharging
    warning-level:       none
    energy:              17.52 Wh
    energy-full:         46.44 Wh
    energy-rate:         16.182 W
    charge-cycles:       N/A
    time to empty:       1.1 hours
    percentage:          37%
    icon-name:          'battery-good-symbolic'
```
